# Contributing

Thanks for your interest in improving the QA Test Management Platform! This
project follows a QA-first workflow — please read the standards below before
opening a pull request.

## Getting Set Up

```bash
npm install
npm run dev        # API :3001 + frontend :5173
```

No database is needed locally (`DATA_DRIVER=memory` by default).

## Branching Strategy

We use a simple trunk-based flow off `main`:

| Prefix | Use |
|--------|-----|
| `feat/` | New feature |
| `fix/` | Bug fix |
| `test/` | Tests only |
| `docs/` | Documentation only |
| `chore/` | Tooling / deps / config |

Example: `fix/dashboard-open-bug-count`

`main` is protected; all changes go through a pull request with green CI.

## Commit Messages (Conventional Commits)

```
feat(projects): add cascade delete for project resources
fix(api): return 422 instead of 500 for duplicate project name
test(metrics): add regression test for open bug count
docs(qa): add exploratory session 4 findings
chore(ci): cache npm in GitHub Actions
```

Keep commits small and focused — one logical change per commit.

## The QA Rule

> A change is **done** only when the relevant tests are written, executed, and passing.

Before you push:

```bash
npm run quality-gate   # lint + type-check + unit + integration + build
npm run test:e2e       # if you changed UI or flows
```

### Adding a Feature
1. Note the requirement / acceptance criteria (in the issue or `docs/qa/requirements.md`).
2. Implement it.
3. Add a **happy-path** test and at least one **negative** test.
4. Run the quality gate.

### Fixing a Bug
1. Reproduce it and file a report using [`docs/qa/bug-report-template.md`](./docs/qa/bug-report-template.md).
2. Write an automated test that **fails** because of the bug (the "red" step).
3. Fix the code so the test **passes** (the "green" step).
4. Run the full suite to confirm **no regressions**.
5. Add a short note to [`docs/qa/learning-log.md`](./docs/qa/learning-log.md).

## Code Style

- TypeScript **strict**; no `any`.
- Small, single-responsibility functions; clear names.
- Handle loading / error / empty states in the UI.
- Validate input on the **server** (never trust the client).
- Run `npm run format` before committing.

## Pull Requests

- Fill in the PR template (the QA checklist is required).
- Link the related issue or bug ID.
- Attach before/after screenshots for UI changes.
- CI must be green before merge.

## Project Conventions

Project-specific rules live in [`.kiro/steering/`](./.kiro/steering):
- `project-standards.md` — architecture, code style, API design, git conventions
- `qa-rules.md` — testing and QA rules

Please keep changes consistent with those documents.
