---
name: Feature request
about: Suggest a new feature or improvement
title: '[FEATURE] '
labels: enhancement
---

## User Story
As a <role>, I want <goal> so that <value>.

## Acceptance Criteria
```
GIVEN ...
WHEN ...
THEN ...
```

## Notes / Risks
<!-- Anything that could affect scope, testing, or design -->
