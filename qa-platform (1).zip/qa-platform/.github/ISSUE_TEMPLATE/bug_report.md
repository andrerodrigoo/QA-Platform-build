---
name: Bug report
about: Report a reproducible defect
title: '[BUG] '
labels: bug
---

## Title
<!-- One sentence: what is wrong and where -->

## Environment
- Browser / OS:
- App version / commit:
- Environment: Local / Staging / Production

## Preconditions
<!-- State that must be true before the steps -->

## Steps to Reproduce
1.
2.
3.

## Actual Result
<!-- What actually happened -->

## Expected Result
<!-- What should have happened -->

## Evidence
<!-- Screenshots, console errors, network requests -->

## Severity
- [ ] Critical
- [ ] High
- [ ] Medium
- [ ] Low

## Frequency
- [ ] Always
- [ ] Often
- [ ] Intermittent
- [ ] Rarely
