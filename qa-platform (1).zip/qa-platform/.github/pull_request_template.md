# Pull Request

## Description
<!-- What does this PR change and why? -->

## Related Issue / Bug
<!-- e.g. Closes #12, Fixes BUG-002 -->

## Type of Change
- [ ] Feature
- [ ] Bug fix
- [ ] Refactor
- [ ] Documentation
- [ ] Test / CI

## QA Checklist (Quality Gate)
- [ ] `npm run lint` passes (0 errors)
- [ ] `npm run type-check` passes (0 errors)
- [ ] `npm run test:unit` passes
- [ ] `npm run test:api` passes
- [ ] `npm run test:e2e` passes (if UI/flow changed)
- [ ] New feature has tests (happy path + at least one negative case)
- [ ] Bug fix includes a regression test that failed before the fix
- [ ] Loading / error / empty states handled (if UI change)
- [ ] Documentation updated (if behavior changed)

## Screenshots / Evidence
<!-- For UI changes, attach before/after screenshots -->
