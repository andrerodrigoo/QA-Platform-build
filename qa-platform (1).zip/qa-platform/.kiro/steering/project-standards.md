# Project Standards — QA Test Management Platform

## Stack

- **Frontend:** React 18 + TypeScript (strict) + Vite
- **Backend:** Node.js + Express + TypeScript (strict)
- **Database:** SQLite via better-sqlite3 (dev/test) — synchronous driver, zero-config
- **ORM/Query:** Drizzle ORM (type-safe, lightweight, no codegen required)
- **Unit/Integration Tests:** Vitest
- **E2E Tests:** Playwright
- **Linting:** ESLint (flat config)
- **Formatting:** Prettier
- **CI/CD:** GitHub Actions

## Project Structure

```
qa-platform/
├── packages/
│   ├── backend/          # Express REST API
│   │   ├── src/
│   │   │   ├── db/       # Drizzle schema, migrations, connection
│   │   │   ├── routes/   # Express route handlers (one file per resource)
│   │   │   ├── services/ # Business logic (pure functions)
│   │   │   ├── validators/ # Zod validation schemas
│   │   │   ├── types/    # Shared TypeScript types
│   │   │   └── index.ts  # App entry point
│   │   └── src/__tests__/
│   │       ├── unit/     # Service and validator tests
│   │       └── integration/ # API endpoint tests
│   └── frontend/         # React + Vite app
│       ├── src/
│       │   ├── components/  # Reusable UI components
│       │   ├── pages/       # Route-level page components
│       │   ├── hooks/       # Custom React hooks (useProjects, useTestCases, etc.)
│       │   ├── api/         # API client functions
│       │   ├── types/       # Frontend TypeScript types (imported from shared)
│       │   └── utils/       # Utility functions
│       └── src/__tests__/
│           └── unit/     # Hook and utility tests
├── e2e/                  # Playwright E2E tests
│   ├── fixtures/         # Test data factories
│   ├── pages/            # Page Object Models (POM)
│   └── tests/            # Test suites
├── docs/
│   └── qa/               # All QA documentation
└── .github/
    └── workflows/        # CI/CD pipelines
```

## Code Style

### TypeScript
- Strict mode ALWAYS enabled (`"strict": true`)
- No `any` type — use `unknown` when type is truly unknown
- Explicit return types on all exported functions
- Use `type` for object shapes, `interface` for extensible contracts
- Use `enum` for: Priority, Severity, Status, ExecutionResult, TestType

### Naming Conventions
- Files: `kebab-case.ts` (e.g., `project-service.ts`)
- Components: `PascalCase.tsx` (e.g., `ProjectCard.tsx`)
- Functions: `camelCase` (e.g., `createProject`)
- Constants: `UPPER_SNAKE_CASE` (e.g., `MAX_NAME_LENGTH`)
- Types/Interfaces: `PascalCase` (e.g., `ProjectCreateInput`)
- Test files: `*.test.ts` or `*.spec.ts`

### Functions
- Keep functions small: single responsibility
- Max 30 lines per function (guideline, not hard rule)
- Prefer pure functions in service layer
- No side effects in validators

### Error Handling
- API errors: always return `{ error: string, details?: object }`
- Never expose stack traces or DB internals in API responses
- Frontend: always handle loading, error, and empty states
- Use `try/catch` in all async operations

### Comments
- No comments for obvious code
- JSDoc for exported public API functions
- Inline comments only for non-obvious business logic

## QA Standards

### Test Requirements
- Every new feature requires unit tests BEFORE merge
- Every bug fix requires a regression test
- Unit test coverage must stay ≥ 70% on `services/` and `validators/`
- E2E smoke suite must pass on every CI run

### Test Naming
```typescript
// Unit tests: describe the unit, then the scenario
describe('ProjectService', () => {
  describe('createProject', () => {
    it('should create a project with valid data', ...)
    it('should throw when name is empty', ...)
    it('should throw when name exceeds 100 characters', ...)
  })
})

// E2E tests: describe the user action
test('user can create a project with valid data', ...)
test('user sees error when submitting empty project name', ...)
```

### What Must Always Be Tested
1. All business rules (BRs) in `services/`
2. All validation rules (FRs) in `validators/`
3. All API error responses (400, 404, 422)
4. All cascade operations
5. Metrics calculations

## API Design

- Base path: `/api`
- RESTful resource naming: plural nouns (`/projects`, `/test-cases`, `/executions`, `/bugs`)
- Status codes:
  - 200: successful GET/PUT
  - 201: successful POST (resource created)
  - 204: successful DELETE (no content)
  - 400: malformed request (bad JSON, invalid ID format)
  - 404: resource not found
  - 409: conflict (duplicate unique field)
  - 422: validation error (valid JSON but business rule violation)
  - 500: unexpected server error
- Error response shape: `{ "error": "Human-readable message", "details"?: [...] }`

## Git Conventions

### Branch Strategy
- `main` — production-ready code; protected
- `feat/description` — new features
- `fix/description` — bug fixes
- `test/description` — test additions
- `docs/description` — documentation only
- `chore/description` — tooling, deps, config

### Commit Messages (Conventional Commits)
```
feat(projects): add cascade delete for project resources
fix(api): return 422 instead of 500 for duplicate project name
test(projects): add regression test for whitespace-only name
docs(qa): add bug report for BUG-001
chore(deps): upgrade vitest to 2.x
```

### Quality Gate (must pass before merge)
1. `npm run lint` — zero errors
2. `npm run type-check` — zero TypeScript errors
3. `npm run test:unit` — all pass
4. `npm run test:api` — all pass
5. `npm run build` — successful
