# QA Rules — QA Test Management Platform

## Core QA Principle

> A feature is DONE only when the relevant tests are written, executed, and passing.  
> Writing code is not "done". Passing tests is "done".

## QA Checklist (per feature)

Before considering any feature complete, verify:

- [ ] Requirements reviewed and understood
- [ ] Acceptance criteria defined (in requirements.md or inline)
- [ ] Happy path test exists (unit or E2E)
- [ ] At least one negative test exists (invalid input, error case)
- [ ] Boundary values tested if character/number limits exist
- [ ] API returns correct HTTP status codes for all scenarios
- [ ] Frontend shows loading state during async operations
- [ ] Frontend shows error state when API fails
- [ ] Frontend shows empty state when list is empty
- [ ] No console errors in browser during normal operation
- [ ] Lint passes with zero errors
- [ ] TypeScript strict mode passes

## Bug Reporting Rules

When a bug is found during development or testing:

1. **STOP** — do not fix it immediately without documenting it
2. **REPRODUCE** — confirm it is reproducible with exact steps
3. **DOCUMENT** — fill in the bug-report-template.md format
4. **CLASSIFY** — assign severity and priority
5. **FIX** — implement the fix
6. **TEST RED FIRST** — write the regression test BEFORE applying the fix (TDD for bug fixes)
7. **FIX → GREEN** — confirm test passes after fix
8. **REGRESSION** — run full suite; confirm nothing else broke
9. **LOG** — add entry to learning-log.md

## Regression Testing Rules

Every bug fix MUST:
- Have an automated test that FAILS before the fix (the "red" step)
- Have that test PASS after the fix (the "green" step)
- Not break any previously passing test

## Test Isolation Rules

- Unit tests: no database, no HTTP calls — mock everything external
- Integration tests: real database (in-memory SQLite); no frontend
- E2E tests: real browser + real backend + real database (test instance)
- Tests must NOT depend on execution order
- Tests must NOT share mutable state

## Validation Rules (Business Logic)

These rules MUST be enforced both client-side (UX) AND server-side (security):

| Rule | Where Enforced |
|------|---------------|
| Project name required | Client + Server |
| Project name max 100 chars | Client + Server |
| Project name unique (case-insensitive) | Server only |
| Test case title required | Client + Server |
| Test case title max 200 chars | Client + Server |
| Test case title unique per project | Server only |
| Steps required | Client + Server |
| Expected result required | Client + Server |
| Priority must be valid enum | Client + Server |
| Type must be valid enum | Client + Server |
| Execution result required | Client + Server |
| Bug title required | Client + Server |
| Severity must be valid enum | Client + Server |

## Security Rules

- Never log raw user input that could contain PII or injection attempts
- Always validate and sanitize on the server even if validated on the client
- Never expose database IDs in error messages in a way that reveals structure
- Never return stack traces in production API responses
- Use parameterized queries (Drizzle ORM handles this automatically)

## Performance Rules

- API reads must respond in < 500ms
- Never make N+1 queries (join in SQL, not in a loop)
- Frontend must not re-render unnecessarily (use proper React deps)

## Documentation Rules

- Every new bug → entry in learning-log.md
- Every architectural decision → entry in learning-log.md
- Every new test suite → brief comment block at the top explaining what is being tested
- Keep docs/qa/ files up to date as features change
