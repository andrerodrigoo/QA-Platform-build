import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

/**
 * Vitest workspace configuration.
 *
 * Three projects separate the test levels/environments from the test strategy:
 *  - `unit-backend`  : node env — services / validators / domain (no DB, no HTTP)
 *  - `unit-frontend` : jsdom env + React plugin — utils, hooks, and routing/component tests
 *  - `integration`   : node env — API + in-memory repository (request -> handler -> repo)
 *
 * E2E tests are handled separately by Playwright (see playwright.config.ts).
 */
export default defineConfig({
  test: {
    projects: [
      {
        test: {
          name: 'unit-backend',
          environment: 'node',
          include: ['packages/backend/src/**/*.unit.test.ts'],
        },
      },
      {
        plugins: [react()],
        test: {
          name: 'unit-frontend',
          environment: 'jsdom',
          globals: true,
          setupFiles: ['packages/frontend/src/test-setup.ts'],
          include: ['packages/frontend/src/**/*.unit.test.{ts,tsx}'],
        },
      },
      {
        test: {
          name: 'integration',
          environment: 'node',
          include: ['packages/backend/src/**/*.integration.test.ts'],
        },
      },
    ],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'html', 'lcov'],
      include: [
        'packages/backend/src/services/**',
        'packages/backend/src/validators/**',
        'packages/backend/src/domain/**',
        'packages/frontend/src/utils/**',
      ],
      thresholds: {
        lines: 70,
        functions: 70,
        branches: 70,
        statements: 70,
      },
    },
  },
});
