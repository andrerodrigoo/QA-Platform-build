import serverless from 'serverless-http';
import { createApp } from '../../packages/backend/src/http/app.js';
import { createRepository } from '../../packages/backend/src/repository/factory.js';

/**
 * Netlify Function entry point.
 *
 * All /api/* requests are redirected here (see netlify.toml). Netlify invokes
 * the function with a path like "/.netlify/functions/api/projects". We rewrite
 * that to "/api/projects" so the Express app (mounted at /api) matches, then
 * hand it to serverless-http.
 *
 * The Express app is created once per cold start and reused across warm
 * invocations for performance.
 */
const FUNCTION_BASE = '/.netlify/functions/api';

const handlerPromise = (async () => {
  const repo = await createRepository();
  const app = createApp(repo);
  return serverless(app);
})();

// Netlify event shape (subset we rely on).
interface NetlifyEvent {
  path: string;
  [key: string]: unknown;
}

export const handler = async (event: NetlifyEvent, context: unknown) => {
  const rest = event.path.startsWith(FUNCTION_BASE)
    ? event.path.slice(FUNCTION_BASE.length)
    : event.path;
  const normalizedPath = `/api${rest === '' || rest === '/' ? '' : rest}`;

  const fn = await handlerPromise;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return (fn as any)({ ...event, path: normalizedPath }, context);
};
