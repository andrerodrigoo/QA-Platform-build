# QA Documentation Index

This folder contains the complete QA documentation for the QA Test Management
Platform. It is designed to demonstrate a professional, end-to-end QA process.

## Reading Order

1. **[requirements.md](./requirements.md)** — *What are we building and why?*  
   Product vision, personas, user stories, functional & non-functional requirements, business rules, acceptance criteria, use cases, and risks.

2. **[test-strategy.md](./test-strategy.md)** — *How will we test it?*  
   Test levels (unit/integration/E2E), test types, the automation pyramid, environments, entry/exit criteria, and regression & smoke strategies.

3. **[test-plan.md](./test-plan.md)** — *The concrete plan.*  
   Schedule, resources, approach, deliverables, test data, risk management, and the release quality gate.

4. **[test-cases.md](./test-cases.md)** — *The test cases.*  
   50+ cases across all modules: positive, negative, boundary value analysis (BVA), equivalence partitioning (EP), and smoke.

5. **[bug-report-template.md](./bug-report-template.md)** — *How we report bugs.*  
   Standard template + a worked example, plus the severity-vs-priority guide and status workflow.

6. **[exploratory-testing.md](./exploratory-testing.md)** — *Unscripted discovery.*  
   Session-Based Test Management charters and findings.

7. **[bug-reports.md](./bug-reports.md)** — *Real bugs found & fixed.*  
   Formal reports for the defects discovered, including root cause and regression test references.

8. **[learning-log.md](./learning-log.md)** — *The story of the build.*  
   A running log of what was built, QA concepts applied, decisions made, bugs found/fixed, and lessons learned — ideal for explaining the project in an interview.

## QA Techniques Demonstrated

- Requirements engineering & acceptance criteria (Given/When/Then)
- Boundary Value Analysis (BVA) & Equivalence Partitioning (EP)
- Positive & negative testing
- The test automation pyramid (unit / integration / E2E)
- Contract/API testing with explicit HTTP status expectations
- Session-Based exploratory testing
- Bug triage (severity vs priority; fix-now vs backlog)
- Test-first bug fixing & regression prevention
- Smoke testing & quality gates in CI/CD
