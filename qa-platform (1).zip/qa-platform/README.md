# ✓ QA Test Management Platform

A full-stack web application for QA teams to manage **projects, test cases, test executions, and bugs**, with a live **QA metrics dashboard**. Built as a portfolio project demonstrating a **professional, QA-driven software development workflow** — from requirements engineering through automated testing, exploratory testing, bug hunting, regression prevention, and CI/CD.

> This project is intentionally as much about **how** it was built (the QA process) as **what** it does. See [`docs/qa/`](./docs/qa) for the full QA documentation set.

---

## ✨ Features

- **Projects** — create, edit, delete; organize everything by project
- **Test Cases** — full CRUD with priority, type, status, steps, expected result
- **Search & Filter** — find test cases by keyword, status, priority, and type
- **Test Execution** — record Pass / Fail / Blocked results with notes and history
- **Bug Management** — report bugs (manually or from a failed test), track severity, priority, and status lifecycle
- **QA Dashboard** — pass/fail/blocked rates, bugs by severity, open-bug counts, per-project summaries

---

## 🧱 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, TypeScript (strict), Vite, React Router |
| Backend | Node.js, Express, TypeScript (strict) |
| Validation | Zod (server-side, shared enums) |
| Database | Neon (serverless Postgres) via Drizzle ORM + `@neondatabase/serverless` |
| Local/Test data | In-memory repository (no DB required) |
| Unit / Integration tests | Vitest + Supertest |
| E2E tests | Playwright |
| Lint / Format | ESLint (flat config) + Prettier |
| CI/CD | GitHub Actions |
| Deploy | Netlify (static frontend + Netlify Functions) |

### Architecture at a glance

```
Browser ──> React SPA (Vite build, static)
                │  fetch /api/*
                ▼
        Netlify redirect  ──>  Netlify Function (Express via serverless-http)
                                     │
                                     ▼
                         Repository interface
                          ├── MemoryRepository   (local dev / tests / CI)
                          └── NeonRepository      (production, Drizzle + Neon)
```

The **Repository pattern** is the key design decision: business logic depends on an
interface, so the entire domain is unit-testable with an in-memory store while
production runs on Neon. The **same Express app** runs locally and inside the
Netlify Function, so tests exercise production code paths.

---

## 🚀 Getting Started

### Prerequisites
- Node.js **20+** (see `.nvmrc`)
- npm 10+

### Install & Run (local, no database needed)

```bash
git clone https://github.com/<your-username>/qa-test-management-platform.git
cd qa-test-management-platform
npm install

# Start API (:3001) and frontend (:5173) together.
npm run dev
```

Open http://localhost:5173. By default `DATA_DRIVER=memory`, so no database is
required for local development.

### Using Neon (Postgres)

1. Create a free database at [neon.tech](https://neon.tech) and copy the connection string.
2. Copy `.env.example` to `.env` and set:
   ```env
   DATABASE_URL=postgresql://...   # from Neon
   DATA_DRIVER=neon
   ```
3. Apply the schema:
   ```bash
   npm run db:generate   # generate migration from the Drizzle schema
   npm run db:migrate    # apply it to Neon
   ```
4. `npm run dev` now persists to Neon.

---

## 🧪 Testing

```bash
npm test              # unit + integration
npm run test:unit     # unit tests (Vitest)
npm run test:api      # integration / API tests (Vitest + Supertest)
npm run test:coverage # coverage report (>= 70% gate on business logic)
npm run test:e2e      # end-to-end tests (Playwright)
```

**Test pyramid:** ~70% unit · ~20% integration · ~10% E2E — see
[`docs/qa/test-strategy.md`](./docs/qa/test-strategy.md).

---

## ✅ Quality Gate

A change is only "done" when all of these pass (enforced in CI):

```bash
npm run quality-gate   # lint + type-check + tests + build
```

| Gate | Command |
|------|---------|
| Lint (0 errors) | `npm run lint` |
| Types (strict, 0 errors) | `npm run type-check` |
| Unit tests | `npm run test:unit` |
| Integration tests | `npm run test:api` |
| E2E tests | `npm run test:e2e` |
| Production build | `npm run build` |

---

## ☁️ Deploy to Netlify

1. Push this repo to GitHub.
2. In Netlify, **Add new site → Import from GitHub** and pick the repo.
3. Netlify reads [`netlify.toml`](./netlify.toml) automatically:
   - Build: `npm run build`
   - Publish dir: `packages/frontend/dist`
   - Functions dir: `netlify/functions`
4. In **Site settings → Environment variables**, set:
   - `DATABASE_URL` = your Neon connection string
   - `DATA_DRIVER` = `neon`
5. Deploy. The frontend calls `/api/*`, which Netlify routes to the Express function.

---

## 📚 QA Documentation

This project ships a complete QA documentation set in [`docs/qa/`](./docs/qa):

| Document | Purpose |
|----------|---------|
| [`requirements.md`](./docs/qa/requirements.md) | Vision, personas, user stories, FR/NFR, business rules, acceptance criteria, risks |
| [`test-strategy.md`](./docs/qa/test-strategy.md) | Test levels, types, automation strategy, entry/exit criteria, regression & smoke strategy |
| [`test-plan.md`](./docs/qa/test-plan.md) | Schedule, resources, approach, deliverables, quality gate |
| [`test-cases.md`](./docs/qa/test-cases.md) | 50+ test cases: positive, negative, BVA, EP, smoke |
| [`bug-report-template.md`](./docs/qa/bug-report-template.md) | Professional bug report format |
| [`exploratory-testing.md`](./docs/qa/exploratory-testing.md) | Session-based exploratory testing charters & findings |
| [`bug-reports.md`](./docs/qa/bug-reports.md) | Real bugs found, documented, and fixed |
| [`learning-log.md`](./docs/qa/learning-log.md) | Running log of QA concepts, decisions, and lessons learned |

---

## 🗂 Project Structure

```
qa-platform/
├── packages/
│   ├── backend/         # Express API, services, repositories, Drizzle schema
│   └── frontend/        # React + Vite SPA
├── netlify/functions/   # Serverless entry (wraps the Express app)
├── e2e/                 # Playwright tests + Page Objects
├── docs/qa/             # QA documentation
├── .github/workflows/   # CI pipeline
└── .kiro/               # Steering rules & hooks (AI-assisted dev config)
```

---

## 📄 License

MIT — see [LICENSE](./LICENSE).

---

*Built with an AI-assisted, QA-first workflow. The process is documented end-to-end in [`docs/qa/learning-log.md`](./docs/qa/learning-log.md).*
